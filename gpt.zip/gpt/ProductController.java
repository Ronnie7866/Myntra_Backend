package com.backend.ecommerce.controllers;


import com.backend.ecommerce.implementation.CategoryServiceImplementation;
import com.backend.ecommerce.implementation.ProductServiceImplementation;
import com.backend.ecommerce.records.ProductResponse;
import com.backend.ecommerce.entity.Product;
import com.backend.ecommerce.service.CategoryService;
import com.backend.ecommerce.service.ProductService;
import com.backend.ecommerce.utility.AppConstants;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@AllArgsConstructor
@RequestMapping("/api/products")
@CrossOrigin("*")
public class ProductController {

    private final ProductService productService;

    @Autowired
    public ProductController(ProductServiceImplementation productService) {
        this.productService = productService;
    }

    @PostMapping
    public ResponseEntity<Product> createProduct(@RequestBody Product product) {
        Product createdProduct = productService.createProduct(product);
        return ResponseEntity.ok(createdProduct);
    }

    @PostMapping("/add-all")
    public ResponseEntity<List<Product>> createListProduct(@RequestBody List<Product> productList) {
        List<Product> products = productService.addAll(productList);
        return ResponseEntity.ok(products);
    }

    @GetMapping
    public ResponseEntity<List<Product>> getAllProducts() {
        List<Product> products = productService.getAllProducts();
        return ResponseEntity.ok(products);
    }
    @GetMapping("/{id}")
    public ResponseEntity<Product> getProductById(@PathVariable Long id) {
        Product productById = productService.getProductById(id);
        return ResponseEntity.ok(productById);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Product> updateProduct(@RequestBody Product product, @PathVariable Long id) {
        Product updatedProduct = productService.updateProduct(id, product);
        return ResponseEntity.ok(updatedProduct);
    }

    @PostMapping("/mapCategory")
    public ResponseEntity<Product> assignProductWithCategory(@RequestParam Long productId, @RequestParam Long categoryId) {
        Product product = productService.assignCategoryToProduct(productId, categoryId);
        return ResponseEntity.ok(product);
    }

    @GetMapping("/getProductByCategory/{id}")
    public ResponseEntity<List<Product>> getProductsByCategory(@PathVariable Long id) {
        List<Product> productByCategory = productService.getProductByCategory(id);
        return ResponseEntity.ok(productByCategory);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Product> deleteProduct(@PathVariable Long id) {
        Product product = productService.deleteProduct(id);
        return ResponseEntity.ok(product);
    }

    @GetMapping("/allProductPage")
    public ResponseEntity<ProductResponse> getAllProductPage(@RequestParam(defaultValue = AppConstants.PAGE_NUMBER, required = false) Integer pageNumber,
                                                                   @RequestParam(defaultValue = AppConstants.PAGE_SIZE, required = false) Integer pageSize) {
        return ResponseEntity.ok(productService.getAllProductWithPagination(pageNumber, pageSize));
    }

    @GetMapping("/allProductPageWithPagination")
    public ResponseEntity<ProductResponse> getAllProductPage(@RequestParam(defaultValue = AppConstants.PAGE_NUMBER, required = false) Integer pageNumber,
                                                             @RequestParam(defaultValue = AppConstants.PAGE_SIZE, required = false) Integer pageSize,
                                                             @RequestParam(defaultValue = AppConstants.SORT_BY, required = false) String sortBy,
                                                             @RequestParam(defaultValue = AppConstants.SORT_ORDER, required = false) String sortOrder) {
        return ResponseEntity.ok(productService.getProductWithPaginationAndSorting(pageNumber, pageSize, sortBy, sortOrder));
    }
}
